package com.acer.example.katalogfilmsub2


import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.fragment_movies.*
import kotlinx.android.synthetic.main.fragment_tv_show.*
import kotlinx.android.synthetic.main.fragment_tv_show.progressBar

/**
 * A simple [Fragment] subclass.
 */
class TvShowFragment : Fragment() {

    private val list = ArrayList<TvShow>()

    private lateinit var adapter: ListTvShowAdapter
    private lateinit var tvShowMainViewModel: TvShowMainModelView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tv_show, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rv_tv_show.setHasFixedSize(true)

        showRecyclerList()
    }


    private fun showRecyclerList() {

        adapter = ListTvShowAdapter()
        adapter.notifyDataSetChanged()

        rv_tv_show.layoutManager = LinearLayoutManager(this.context)
        rv_tv_show.adapter = adapter

        tvShowMainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(TvShowMainModelView::class.java)
        tvShowMainViewModel.setTvShow()
        showLoading(true)
        tvShowMainViewModel.getTvShow().observe(this, androidx.lifecycle.Observer { tvshow ->
            if (tvshow != null){
                adapter.setData(tvshow)
                showLoading(false)
            }
        })

       adapter.setOnItemClickCallback(object : ListTvShowAdapter.OnItemClickCallback{
            override fun onItemClicked(data: TvShow) {
                showSelectedTvShow(data)
            }
        })
    }

    private fun showSelectedTvShow(tvshow: TvShow) {
        Toast.makeText(this.context, "Kamu memilih ${tvshow.judul}", Toast.LENGTH_SHORT).show()

        val tvshow = TvShow(tvshow.id, tvshow.judul, tvshow.deskripsi, tvshow.poster)
        val moveDetailTvShowActivity= Intent(this.context, DetailTvShowActivity::class.java)
        moveDetailTvShowActivity.putExtra(DetailTvShowActivity.EXTRA_TV_SHOW, tvshow)
        startActivity(moveDetailTvShowActivity)
    }

    private fun showLoading(state: Boolean){
        if (state){
            progressBar.visibility = View.VISIBLE
        }else{
            progressBar.visibility = View.GONE
        }
    }

}

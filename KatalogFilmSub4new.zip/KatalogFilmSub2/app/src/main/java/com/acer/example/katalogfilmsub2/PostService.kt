package com.acer.example.katalogfilmsub2

import android.provider.Settings.Global.getString
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.http.GET
import java.util.*

interface PostService {

    @GET("3/discover/movie?api_key=e5ffacd3e2daf66fcfe8be92718237f5&language=en-US")
    fun getJson(): Call<JsonObject>

    @GET("3/discover/tv?api_key=e5ffacd3e2daf66fcfe8be92718237f5&language=en-US")
    fun getJsonTvShow(): Call<JsonObject>
}
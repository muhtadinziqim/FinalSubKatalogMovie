package com.acer.example.katalogfilmsub2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.acer.example.katalogfilmsub2.db.DatabaseHelper
import com.acer.example.katalogfilmsub2.favorite_list.MovieFavActivity
import com.acer.example.katalogfilmsub2.favorite_list.TvShowFavActivity
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_movies.*

class MainActivity : AppCompatActivity() {

    private lateinit var dataBaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dataBaseHelper = DatabaseHelper(this)

        val sectionsPagerAdapter = SectionsPagerAdapter(this, supportFragmentManager)
        view_pager.adapter = sectionsPagerAdapter
        tabs.setupWithViewPager(view_pager)

        supportActionBar?.elevation = 0f

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_change_settings) {
            val mIntent = Intent(Settings.ACTION_LOCALE_SETTINGS)
            startActivity(mIntent)
        }
        if (item.itemId == R.id.view_fav_movie) {
//            Toast.makeText(this, "Menu Fav Movie", Toast.LENGTH_LONG).show()
            val favMovieIntent = Intent(this@MainActivity, MovieFavActivity::class.java)
            startActivity(favMovieIntent)
        }
        if (item.itemId == R.id.view_fav_tvshow) {
//            Toast.makeText(this, "Menu Fav TvShow", Toast.LENGTH_LONG).show()
            val favTvShowIntent = Intent(this@MainActivity, TvShowFavActivity::class.java)
            startActivity(favTvShowIntent)
        }
        return super.onOptionsItemSelected(item)
    }


}

package com.acer.example.katalogfilmsub2


import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.acer.example.katalogfilmsub2.db.DatabaseHelper
import com.acer.example.katalogfilmsub2.db.FavHelper
import kotlinx.android.synthetic.main.fragment_movies.*
import kotlinx.android.synthetic.main.item_row_movie.*
import java.util.Observer

/**
 * A simple [Fragment] subclass.
 */
class MoviesFragment : Fragment() {

    private val list = ArrayList<Movie>()

    private lateinit var adapter: MovieAdapter
    private lateinit var movieMainViewModel: MovieMainViewModel


    private var databaseHelper: DatabaseHelper? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_movies, container, false)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        databaseHelper = DatabaseHelper(requireContext())
//        favHelper = FavHelper.getInstance(context)
        rv_movies.setHasFixedSize(true)

//        list.addAll(getListMovies())
        showRecyclerList()
    }

//
    private fun showRecyclerList() {

        adapter = MovieAdapter()
        adapter.notifyDataSetChanged()

        rv_movies.layoutManager = LinearLayoutManager(this.context)
//        val listMovieAdapter = ListMovieAdapter(list)
        rv_movies.adapter = adapter

        movieMainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(MovieMainViewModel::class.java)
        movieMainViewModel.setMovie()
        showLoading(true)
        movieMainViewModel.getmovies().observe(this, androidx.lifecycle.Observer { movie ->
            if (movie != null){
                adapter.setData(movie)
                showLoading(false)
            }
        })

        adapter.setOnItemClickCallback(object : MovieAdapter.OnItemClickCallback{
            override fun onItemClicked(data: Movie) {
                showSelectedMovie(data)
            }
        })

    }


    private fun showSelectedMovie(movie: Movie) {
        Toast.makeText(this.context, "Kamu memilih ${movie.judul}", Toast.LENGTH_SHORT).show()

        val movie = Movie(movie.judul, movie.deskripsi, movie.poster)
        val moveDetailActivity= Intent(this.context, DetailActivity::class.java)
        moveDetailActivity.putExtra(DetailActivity.EXTRA_MOVIE, movie)
        startActivity(moveDetailActivity)
    }

    private fun showLoading(state: Boolean){
        if (state){
            progressBar.visibility = View.VISIBLE
        }else{
            progressBar.visibility = View.GONE
        }
    }

}

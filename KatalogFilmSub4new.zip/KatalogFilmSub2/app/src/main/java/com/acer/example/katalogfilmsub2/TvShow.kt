package com.acer.example.katalogfilmsub2

import android.os.Parcel
import android.os.Parcelable

data class TvShow (
    var judul: String,
    var deskripsi: String,
    var poster: String
): Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readString()
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flag: Int) {
        parcel.writeString(judul)
        parcel.writeString(deskripsi)
        parcel.writeString(poster)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<TvShow> {
        override fun createFromParcel(parcel: Parcel): TvShow {
            return TvShow(parcel)
        }

        override fun newArray(size: Int): Array<TvShow?> {
            return arrayOfNulls(size)
        }
    }
}
